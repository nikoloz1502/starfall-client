"use strict";
/* Animated backgrounds for the Play tab. Every scene is a pure function of time, so the same code draws the live
   background and the small previews in Settings. Rendered at reduced resolution (pixel style: 1/4, smooth: 1/2). */

const WALLS = [["space", "Космос"], ["sunset", "Закат"], ["aurora", "Сияние"], ["stars", "Звездопад"], ["nebula", "Туманность"]];

const BG = (() => {
  const H = i => { const x = Math.sin(i * 12.9898 + 78.233) * 43758.5453; return x - Math.floor(x); };
  const rgb = hex => { const n = parseInt(String(hex).replace("#", ""), 16) || 0x5b8cff; return [n >> 16 & 255, n >> 8 & 255, n & 255]; };
  const rgba = (c, a) => `rgba(${c[0]},${c[1]},${c[2]},${a})`;
  const mix = (a, b, t) => [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t].map(Math.round);

  function stars(g, w, h, t, count, maxY = 1, speed = 0) {
    for (let i = 0; i < count; i++) {
      const layer = i % 3;
      let x = H(i) * w - t * speed * (layer + 1) * 4;
      x = ((x % w) + w) % w;
      const y = H(i + 999) * h * maxY;
      const tw = .45 + .55 * Math.abs(Math.sin(t * (0.6 + H(i + 7) * 1.8) + i));
      g.globalAlpha = tw * (0.5 + layer * 0.25);
      const s = layer === 2 ? 1.4 : layer === 1 ? 1 : .7;
      g.fillStyle = layer === 2 && i % 7 === 0 ? "#cfe0ff" : "#fff";
      g.fillRect(x, y, s, s);
    }
    g.globalAlpha = 1;
  }

  function shooting(g, w, h, t, n, color) {
    g.lineCap = "round";
    for (let k = 0; k < n; k++) {
      const period = 5 + H(k + 50) * 7, phase = ((t + H(k + 70) * period) % period) / period;
      if (phase > 0.25) continue;
      const p = phase / 0.25;
      const sx = (0.2 + H(k + 90 + Math.floor((t + H(k + 70) * period) / period)) * 1.0) * w, sy = -10 + H(k + 30) * h * 0.3;
      const x = sx - p * w * 0.45, y = sy + p * h * 0.35, len = Math.min(w, h) * 0.12;
      const gr = g.createLinearGradient(x, y, x + len, y - len * 0.75);
      gr.addColorStop(0, `rgba(255,255,255,${1 - p})`); gr.addColorStop(1, rgba(color, 0));
      g.strokeStyle = gr; g.lineWidth = Math.max(1, w / 700);
      g.beginPath(); g.moveTo(x, y); g.lineTo(x + len, y - len * 0.75); g.stroke();
    }
  }

  // ------------------------------------------------------------------ space: nebula, parallax stars, ringed planet, moon
  function space(g, w, h, t, o) {
    const sky = g.createLinearGradient(0, 0, w, h);
    sky.addColorStop(0, "#02030a"); sky.addColorStop(1, "#0a0c22");
    g.fillStyle = sky; g.fillRect(0, 0, w, h);
    g.globalCompositeOperation = "lighter";
    [[o.accent, .32, .25, .55], [[255, 80, 190], .7, .2, .4], [[60, 200, 255], .45, .75, .35]].forEach(([c, cx, cy, r], k) => {
      const x = w * (cx + .04 * Math.sin(t * .05 + k)), y = h * (cy + .05 * Math.cos(t * .04 + k * 2)), R = Math.max(w, h) * r;
      const gr = g.createRadialGradient(x, y, 0, x, y, R);
      gr.addColorStop(0, rgba(c, .22)); gr.addColorStop(1, rgba(c, 0));
      g.fillStyle = gr; g.fillRect(0, 0, w, h);
    });
    g.globalCompositeOperation = "source-over";
    stars(g, w, h, t, o.stars, 1, 0.6);

    // planet with drifting bands, a shadowed side and a ring
    const px = w * .78, py = h * .78, pr = Math.min(w, h) * .32;
    const base = mix(o.accent, [120, 70, 200], .35);
    const ring = (front) => {
      g.save(); g.translate(px, py); g.rotate(-0.35); g.scale(1, .28);
      g.beginPath(); g.arc(0, 0, pr * 1.75, front ? 0 : Math.PI, front ? Math.PI : Math.PI * 2);
      g.lineWidth = pr * .16; g.strokeStyle = rgba(mix(base, [255, 255, 255], .5), front ? .55 : .3); g.stroke();
      g.lineWidth = pr * .05; g.strokeStyle = rgba([255, 255, 255], front ? .35 : .15); g.beginPath(); g.arc(0, 0, pr * 1.55, front ? 0 : Math.PI, front ? Math.PI : Math.PI * 2); g.stroke();
      g.restore();
    };
    ring(false);
    const glow = g.createRadialGradient(px, py, pr * .9, px, py, pr * 1.35);
    glow.addColorStop(0, rgba(base, .45)); glow.addColorStop(1, rgba(base, 0));
    g.fillStyle = glow; g.fillRect(px - pr * 1.5, py - pr * 1.5, pr * 3, pr * 3);
    g.save(); g.beginPath(); g.arc(px, py, pr, 0, Math.PI * 2); g.clip();
    const body = g.createLinearGradient(px - pr, py - pr, px + pr, py + pr);
    body.addColorStop(0, rgba(mix(base, [255, 255, 255], .35), 1)); body.addColorStop(1, rgba(mix(base, [0, 0, 0], .5), 1));
    g.fillStyle = body; g.fillRect(px - pr, py - pr, pr * 2, pr * 2);
    for (let i = 0; i < 7; i++) {
      const by = py - pr + (i + .5) * pr * 2 / 7 + Math.sin(t * .3 + i) * pr * .03;
      g.fillStyle = rgba(i % 2 ? [255, 255, 255] : [0, 0, 0], .08 + .04 * Math.sin(t * .2 + i * 1.7));
      g.fillRect(px - pr, by, pr * 2, pr * (0.12 + .06 * H(i)));
    }
    const shade = g.createRadialGradient(px - pr * .45, py - pr * .45, pr * .2, px, py, pr * 1.1);
    shade.addColorStop(0, "rgba(0,0,0,0)"); shade.addColorStop(1, "rgba(0,0,12,.75)");
    g.fillStyle = shade; g.fillRect(px - pr, py - pr, pr * 2, pr * 2);
    g.restore();
    ring(true);
    // moon on an orbit
    const a = t * .12, mx = px + Math.cos(a) * pr * 2.3, my = py + Math.sin(a) * pr * .7 - pr * .2, mr = pr * .13;
    if (Math.sin(a) > -0.2 || Math.hypot(mx - px, my - py) > pr) {
      const mg = g.createRadialGradient(mx - mr * .4, my - mr * .4, 0, mx, my, mr);
      mg.addColorStop(0, "#e8ecf5"); mg.addColorStop(1, "#59607a");
      g.fillStyle = mg; g.beginPath(); g.arc(mx, my, mr, 0, Math.PI * 2); g.fill();
    }
    if (o.motion) shooting(g, w, h, t, 2 + o.level, o.accent);
  }

  // ------------------------------------------------------------------ sunset: moving sun, layered mountains, clouds, lake
  function ridge(x, seed, rough) {
    return Math.sin(x * .004 + seed) * .5 + Math.sin(x * .011 + seed * 2) * .25 * rough + Math.sin(x * .027 + seed * 3) * .1 * rough;
  }
  function sunset(g, w, h, t, o) {
    const k = .5 + .5 * Math.sin(t * .05);                      // slow breathing of the colours
    const horizon = h * .68;
    const sky = g.createLinearGradient(0, 0, 0, horizon);
    sky.addColorStop(0, rgba(mix([30, 16, 70], [48, 20, 90], k), 1));
    sky.addColorStop(.45, rgba(mix([160, 50, 120], [200, 70, 120], k), 1));
    sky.addColorStop(.78, rgba(mix([255, 120, 70], [255, 150, 80], k), 1));
    sky.addColorStop(1, rgba([255, 205, 120], 1));
    g.fillStyle = sky; g.fillRect(0, 0, w, horizon + 1);
    stars(g, w, h, t, Math.round(o.stars * .4), .3, 0);

    const sunY = horizon - h * (.12 + .05 * Math.sin(t * .07)), sunR = Math.min(w, h) * .12, sx = w * .5;
    const halo = g.createRadialGradient(sx, sunY, sunR * .5, sx, sunY, sunR * 4);
    halo.addColorStop(0, "rgba(255,220,140,.55)"); halo.addColorStop(1, "rgba(255,120,80,0)");
    g.fillStyle = halo; g.fillRect(0, 0, w, horizon);
    const sun = g.createLinearGradient(0, sunY - sunR, 0, sunY + sunR);
    sun.addColorStop(0, "#fff3b0"); sun.addColorStop(1, "#ff8a3c");
    g.fillStyle = sun; g.beginPath(); g.arc(sx, sunY, sunR, 0, Math.PI * 2); g.fill();

    // clouds drifting
    for (let i = 0; i < 6 + o.level * 2; i++) {
      const cw = w * (.18 + H(i) * .2), ch = h * (.025 + H(i + 3) * .03);
      let cx = (H(i + 11) * w * 1.4 + t * (8 + H(i) * 10) * o.speedMul) % (w * 1.4) - w * .2;
      const cy = h * (.12 + H(i + 5) * .4);
      const col = mix([255, 150, 170], [255, 200, 150], H(i + 8));
      g.fillStyle = rgba(col, .35 + .25 * H(i + 2));
      g.beginPath(); g.ellipse(cx, cy, cw / 2, ch / 2, 0, 0, Math.PI * 2); g.fill();
      g.beginPath(); g.ellipse(cx + cw * .2, cy - ch * .35, cw * .3, ch * .5, 0, 0, Math.PI * 2); g.fill();
    }

    // mountains: three layers, darker and slower in front
    const layers = [[.56, [120, 50, 110], 10, .4, .6], [.62, [70, 28, 80], 20, .8, .9], [.7, [30, 12, 40], 35, 1.2, 1.2]];
    layers.forEach(([base, col, amp, seed, rough], li) => {
      g.fillStyle = rgba(col, 1);
      g.beginPath(); g.moveTo(0, h);
      const off = t * (2 + li * 3) * o.speedMul;
      for (let x = 0; x <= w + 8; x += 6) g.lineTo(x, h * base - ridge(x + off, seed * 7, rough) * amp * h / 200 - amp * h / 400);
      g.lineTo(w, h); g.closePath(); g.fill();
    });

    // lake with the sun's shimmering reflection
    const lakeTop = h * .78;
    const lake = g.createLinearGradient(0, lakeTop, 0, h);
    lake.addColorStop(0, "rgba(90,40,90,.95)"); lake.addColorStop(1, "rgba(15,8,28,1)");
    g.fillStyle = lake; g.fillRect(0, lakeTop, w, h - lakeTop);
    for (let i = 0; i < 14; i++) {
      const y = lakeTop + 4 + i * (h - lakeTop) / 15;
      const lw = sunR * (1.8 - i * .1) * (0.7 + .3 * Math.sin(t * 2 + i * 1.3));
      g.fillStyle = `rgba(255,${190 - i * 6},${120 - i * 4},${.55 - i * .035})`;
      g.fillRect(sx - lw / 2 + Math.sin(t * 1.5 + i) * 4, y, lw, Math.max(1, h / 300));
    }

    // birds crossing now and then
    if (o.motion) for (let b = 0; b < 3; b++) {
      const period = 18 + b * 5, p = ((t + b * 7) % period) / period;
      const bx = -40 + p * (w + 80), by = h * (.25 + b * .06) + Math.sin(p * 20) * 6, wing = Math.sin(t * 8 + b) * 4 + 5;
      g.strokeStyle = "rgba(40,15,45,.8)"; g.lineWidth = Math.max(1, w / 800);
      g.beginPath(); g.moveTo(bx - 7, by - wing); g.lineTo(bx, by); g.lineTo(bx + 7, by - wing); g.stroke();
    }
  }

  // ------------------------------------------------------------------ aurora / starfall / nebula
  function aurora(g, w, h, t, o) {
    const sky = g.createLinearGradient(0, 0, 0, h);
    sky.addColorStop(0, "#05060c"); sky.addColorStop(1, "#0b1020");
    g.fillStyle = sky; g.fillRect(0, 0, w, h);
    stars(g, w, h, t, o.stars, 1, 0);
    g.globalCompositeOperation = "lighter";
    for (let k = 0; k < 3; k++) {
      const col = k === 1 ? [90, 255, 200] : k === 2 ? [190, 110, 255] : o.accent;
      g.beginPath();
      for (let x = 0; x <= w; x += 6) {
        const y = h * (.32 + k * .09) + Math.sin(x * .008 / o.scale + t * .5 + k * 2) * h * .07 + Math.sin(x * .021 / o.scale - t * .8 + k) * h * .025;
        x === 0 ? g.moveTo(x, y) : g.lineTo(x, y);
      }
      g.lineTo(w, h); g.lineTo(0, h); g.closePath();
      const gr = g.createLinearGradient(0, h * (.2 + k * .09), 0, h * (.75 + k * .05));
      gr.addColorStop(0, rgba(col, 0)); gr.addColorStop(.15, rgba(col, .28)); gr.addColorStop(1, rgba(col, 0));
      g.fillStyle = gr; g.fill();
    }
    g.globalCompositeOperation = "source-over";
    if (o.motion) shooting(g, w, h, t, 1 + o.level, o.accent);
  }
  function starfall(g, w, h, t, o) {
    const sky = g.createLinearGradient(0, 0, 0, h);
    sky.addColorStop(0, "#03040a"); sky.addColorStop(1, "#0d1226");
    g.fillStyle = sky; g.fillRect(0, 0, w, h);
    stars(g, w, h, t, o.stars * 1.5, 1, 0.3);
    if (o.motion) shooting(g, w, h, t, 5 + o.level * 4, o.accent);
  }
  function nebula(g, w, h, t, o) {
    g.fillStyle = "#07040f"; g.fillRect(0, 0, w, h);
    stars(g, w, h, t, o.stars, 1, 0.2);
    g.globalCompositeOperation = "lighter";
    [o.accent, [255, 90, 200], [80, 200, 255]].forEach((col, k) => {
      const x = w * (.5 + .3 * Math.sin(t * .13 + k * 2.1)), y = h * (.5 + .25 * Math.cos(t * .11 + k * 1.7)), r = Math.max(w, h) * (.35 + .05 * Math.sin(t * .3 + k));
      const gr = g.createRadialGradient(x, y, 0, x, y, r);
      gr.addColorStop(0, rgba(col, .32)); gr.addColorStop(1, rgba(col, 0));
      g.fillStyle = gr; g.fillRect(0, 0, w, h);
    });
    g.globalCompositeOperation = "source-over";
    if (o.motion) shooting(g, w, h, t, 1 + o.level, o.accent);
  }
  const SCENES = { space, sunset, aurora, stars: starfall, nebula };

  function opts(w) {
    const level = Math.max(0, Math.min(3, +(S.Particles ?? 2)));
    return {
      accent: rgb(getComputedStyle(document.documentElement).getPropertyValue("--accent").trim() || "#5B8CFF"),
      level, stars: Math.round([50, 110, 180, 280][level] * Math.max(.4, w / 600)),
      motion: !S.ReduceMotion, speedMul: 1, scale: w / 600,
    };
  }
  function draw(g, w, h, t, mode) {
    (SCENES[mode] || space)(g, w, h, t, opts(w));
    const o = opts(w);
    const glow = g.createRadialGradient(w / 2, h * 1.15, 0, w / 2, h * 1.15, h * .9);
    glow.addColorStop(0, rgba(o.accent, mode === "sunset" ? .12 : .3)); glow.addColorStop(1, rgba(o.accent, 0));
    g.fillStyle = glow; g.fillRect(0, 0, w, h);
  }

  // ------------------------------------------------------------------ live canvas
  const c = $("#bg"), g = c.getContext("2d");
  let simTime = 20, last = performance.now();
  function frame(now) {
    requestAnimationFrame(frame);
    const dt = Math.min(.1, (now - last) / 1000);
    last = now;
    if (currentTab !== "play" || document.hidden) return;
    const pixel = document.documentElement.dataset.style === "pixel";
    const scale = pixel ? .25 : .5;
    const w = Math.max(1, Math.floor(c.clientWidth * scale)), h = Math.max(1, Math.floor(c.clientHeight * scale));
    if (c.width !== w || c.height !== h) { c.width = w; c.height = h; }
    simTime += dt * (+S.AnimSpeed || 1) * (S.ReduceMotion ? .3 : 1);
    draw(g, w, h, simTime, S.Wallpaper || "space");
  }
  requestAnimationFrame(frame);

  return {
    /** Draws a still frame of each scene into the small canvases in Settings. */
    previews(root) {
      root.querySelectorAll("canvas[data-prev]").forEach(cv => draw(cv.getContext("2d"), cv.width, cv.height, 24, cv.dataset.prev));
    },
  };
})();
