"use strict";
/* ================================================================ bridge */
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const HOST = window.chrome && window.chrome.webview;
const pending = new Map();
let seq = 0;

function api(method, args = {}) {
  if (!HOST) return MOCK(method, args);
  return new Promise((resolve, reject) => {
    const id = String(++seq);
    pending.set(id, { resolve, reject });
    HOST.postMessage({ id, method, args });
  });
}
if (HOST) HOST.addEventListener("message", e => {
  const m = e.data;
  if (m.event === "progress") return onProgress(m.text, m.value);
  if (m.event === "game") return onGame(m);
  const p = pending.get(m.id);
  if (!p) return;
  pending.delete(m.id);
  m.error ? p.reject(new Error(m.error)) : p.resolve(m.result);
});

function toast(text, err = false) {
  const t = document.createElement("div");
  t.className = "toast" + (err ? " err" : "");
  t.textContent = text;
  $("#toasts").appendChild(t);
  setTimeout(() => { t.style.transition = "opacity .3s"; t.style.opacity = 0; setTimeout(() => t.remove(), 300); }, err ? 6000 : 3200);
}
function fail(e) {
  let msg = e && e.message || String(e);
  if (msg === "NO_CF_KEY") msg = T("Введите ключ CurseForge в настройках");
  if (msg === "NO_ACCOUNT") { openAccounts(); msg = T("Сначала войдите в аккаунт"); }
  toast(T("Ошибка") + ": " + msg, true);
}

let progressTimer;
function onProgress(text, value) {
  $("#progress").classList.remove("hidden");
  $("#ptext").textContent = text;
  $("#pbar").style.width = Math.round(Math.max(0, Math.min(1, value)) * 100) + "%";
  clearTimeout(progressTimer);
  if (value >= 1) progressTimer = setTimeout(() => $("#progress").classList.add("hidden"), 1500);
}

/* ================================================================ state */
let S = {};          // settings
let BUILDS = [];
let INFO = { releases: [], main: "", running: false };

async function saveSettings(patch, quiet = true) {
  Object.assign(S, patch);
  const clean = { ...S };
  delete clean.instancesResolved; delete clean.gameDir; delete clean.launcherVersion; delete clean.defaultRepo;
  try {
    await api("settings.set", clean);
    if (!quiet) toast(T("Сохранено"));
  } catch (e) { fail(e); }
}

function applyLook() {
  const lang = S.Language === "auto" ? (navigator.language || "ru").slice(0, 2) === "ru" ? "ru" : "en" : S.Language;
  LANG = lang;
  const root = document.documentElement;
  root.lang = lang;
  root.dataset.theme = S.Theme || "dark";
  root.dataset.style = S.Style === "pixel" ? "pixel" : "smooth";
  root.dataset.motion = S.ReduceMotion ? "reduce" : "full";
  root.style.setProperty("--accent", S.Accent || "#5B8CFF");
  root.style.setProperty("--radius", (S.Style === "pixel" ? 0 : (S.Radius ?? 12)) + "px");
  root.style.setProperty("--panel-alpha", ((S.PanelOpacity ?? 85) / 100).toFixed(2));
  const news = document.querySelector(".news");
  if (news) news.classList.toggle("hidden", S.ShowNews === false);
  applyI18n();
}

/* ================================================================ window */
$$("[data-win]").forEach(b => b.onclick = () => api("window." + b.dataset.win));
$("#drag").addEventListener("mousedown", e => { if (e.button === 0) api("window.drag"); });
$("#drag").addEventListener("dblclick", () => api("window.maximize"));
$(".brand").addEventListener("mousedown", e => { if (e.button === 0) api("window.drag"); });

/* ================================================================ tabs */
let currentTab = "play";
$$(".tab").forEach(b => b.onclick = () => showTab(b.dataset.tab));
function showTab(name) {
  currentTab = name;
  $$(".tab").forEach(b => b.classList.toggle("active", b.dataset.tab === name));
  $$(".page").forEach(p => p.classList.toggle("active", p.id === "tab-" + name));
  if (name === "builds") renderBuilds();
  if (name === "friends") loadFriends();
  if (name === "settings") renderSettings();
  if (name === "play") refreshPlay();
}

/* ================================================================ play */
const NEWS = [
  ["1.0.8", ["Starfall для 1.16.5 и 1.8.9, пиксельная косметика из вокселей", "Starfall for 1.16.5 and 1.8.9, voxel pixel-art cosmetics"]],
  ["1.0.7", ["Интеграция Simple Voice Chat: оформление, индикаторы говорящих", "Simple Voice Chat integration: styled UI, speaker indicators"]],
  ["1.0.6", ["Исправлен вылет при запуске", "Fixed a crash on startup"]],
  ["1.0.5", ["Английский язык, метки для друзей, косметика, значок Starfall у ников", "English, friend markers, cosmetics, Starfall badge on nametags"]],
  ["1.0.4", ["Эффекты удара и убийства, hit color, варианты взмаха руки", "Hit and kill effects, hit color, swing styles"]],
  ["1.0.3", ["Плавный шрифт, переключатель пиксельного стиля", "Smooth font, pixel style toggle"]],
  ["1.0.2", ["Жидкое стекло, логотип в инвентаре, HUD под тему", "Liquid glass, inventory logo, themed HUD"]],
];
function renderNews() {
  $("#news-list").innerHTML = NEWS.map(([v, t]) => `<h4>Starfall ${esc(v)}</h4><ul><li>${esc(LANG === "en" ? t[1] : t[0])}</li></ul>`).join("");
}

async function loadBuilds() {
  try { BUILDS = await api("builds.list") || []; } catch (e) { fail(e); BUILDS = []; }
}

async function refreshPlay() {
  try { INFO = await api("play.info"); } catch (e) { fail(e); }
  const pb = $("#pick-build"), pv = $("#pick-version");
  pb.innerHTML = BUILDS.length
    ? BUILDS.map(b => `<option value="${esc(b.id)}" ${b.isMain ? "selected" : ""}>${esc(b.name)} · ${esc(b.minecraft)} ${esc(b.loader)}</option>`).join("")
    : `<option value="">${esc(T("Нет сборок"))}</option>`;
  const cur = BUILDS.find(b => b.id === pb.value);
  const rel = (INFO.releases || []).filter(r => !cur || r.minecraft === cur.minecraft);
  pv.innerHTML = `<option value="latest">${esc(T("Последняя"))}${rel[0] ? " (" + esc(rel[0].version) + ")" : ""}</option>` +
    rel.map(r => `<option value="${esc(r.version)}">${esc(r.version)} · MC ${esc(r.minecraft)}</option>`).join("");
  pv.value = rel.some(r => r.version === S.StarfallVersion) ? S.StarfallVersion : "latest";
  pv.disabled = !cur || !cur.starfall;
  updatePlayButton();
}

function updatePlayButton() {
  const b = BUILDS.find(x => x.id === $("#pick-build").value);
  const btn = $("#play");
  if (INFO.running) {
    $("#play-label").textContent = T("ИГРА ЗАПУЩЕНА");
    btn.classList.add("busy");
  } else if (!btn.dataset.launching) {
    $("#play-label").textContent = T("ИГРАТЬ");
    btn.classList.remove("busy");
  }
  $("#play-sub").textContent = b ? `${b.name} · Minecraft ${b.minecraft}` : "";
  const st = $("#play-status");
  if (!ACC.active) st.textContent = T("Сначала войдите в аккаунт");
  else if (b) st.textContent = b.starfall ? `Starfall ${b.starfall} · ${b.mods} ${LANG === "en" ? "mods" : "модов"}` : T("Starfall не установлен");
  else st.textContent = "";
}

$("#pick-build").onchange = async () => {
  const id = $("#pick-build").value;
  if (!id) return;
  await api("builds.setMain", { id }).catch(fail);
  S.MainBuild = id;
  BUILDS.forEach(b => b.isMain = b.id === id);
  refreshPlay();
};
$("#pick-version").onchange = () => saveSettings({ StarfallVersion: $("#pick-version").value });

$("#play").onclick = async () => {
  const id = $("#pick-build").value;
  if (!id) { toast(T("Сначала создайте сборку"), true); return showTab("builds"); }
  if (!ACC.active) return openAccounts();
  const btn = $("#play");
  btn.dataset.launching = "1";
  btn.classList.add("busy");
  $("#play-label").textContent = T("ЗАПУСК...");
  try {
    const installed = await api("play.launch", { id });
    INFO.running = true;
    toast(T("Игра запускается…") + (installed ? " Starfall " + installed : ""));
  } catch (e) { fail(e); }
  delete btn.dataset.launching;
  updatePlayButton();
};

function onGame(m) {
  if (m.state === "running") INFO.running = true;
  if (m.state === "exited") {
    INFO.running = false;
    if (m.code !== 0) {
      const t = document.createElement("div");
      t.className = "toast err";
      t.innerHTML = `${esc(T("Игра закрылась с ошибкой (код"))} ${esc(m.code)}). <button class="link">${esc(T("Открыть логи"))}</button>`;
      $("button", t).onclick = () => api("builds.logs", { id: m.id });
      $("#toasts").appendChild(t);
      setTimeout(() => t.remove(), 15000);
    }
  }
  updatePlayButton();
}

/* ================================================================ accounts */
let ACC = { accounts: [], active: null };
async function loadAccounts() {
  try { ACC = await api("accounts.list"); } catch (e) { fail(e); }
  renderAccountCard();
}
function renderAccountCard() {
  const a = ACC.accounts.find(x => x.uuid === ACC.active);
  $("#acc-avatar").outerHTML = a ? avatar(a.name).replace('class="avatar"', 'class="avatar" id="acc-avatar"') : `<div class="avatar" id="acc-avatar" style="background:var(--line)">?</div>`;
  $("#acc-name").textContent = a ? a.name : T("Войти");
  $("#acc-type").textContent = a ? (a.type === "msa" ? T("Аккаунт Microsoft") : T("Офлайн")) : T("Аккаунты");
  if (currentTab === "play") updatePlayButton();
}
$("#account").onclick = () => openAccounts();
function openAccounts() {
  const list = ACC.accounts.map(a => `
    <div class="accrow ${a.uuid === ACC.active ? "sel" : ""}" data-u="${esc(a.uuid)}">${avatar(a.name)}
      <div><div class="bname">${esc(a.name)}</div><div class="bmeta">${esc(a.type === "msa" ? T("Аккаунт Microsoft") : T("Офлайн"))}</div></div>
      <button class="btn small danger x">✕</button></div>`).join("");
  modal(`<h2>${esc(T("Аккаунты"))}</h2>
    <div class="acclist">${list || `<div class="hint">${esc(T("Нет аккаунтов"))}</div>`}</div>
    <button class="btn ms" id="acc-ms" style="width:100%"><svg width="12" height="12" viewBox="0 0 2 2" style="margin-right:8px;vertical-align:-1px"><rect width=".95" height=".95" fill="#f25022"/><rect x="1.05" width=".95" height=".95" fill="#7fba00"/><rect y="1.05" width=".95" height=".95" fill="#00a4ef"/><rect x="1.05" y="1.05" width=".95" height=".95" fill="#ffb900"/></svg>${esc(T("Войти через Microsoft"))}</button>
    <div class="section-title" style="margin-top:16px">${esc(T("Офлайн-аккаунт"))}</div>
    <div class="row gap"><input id="acc-off" maxlength="16" placeholder="${esc(T("Ник для офлайн-игры"))}" style="flex:1;min-width:0"><button class="btn" id="acc-off-add">${esc(T("Добавить"))}</button></div>
    <div class="hint">${esc(T("Офлайн-аккаунт работает в одиночной игре и на серверах без лицензии."))}</div>
    <div class="foot"><button class="btn" id="acc-close">${esc(T("Закрыть"))}</button></div>`);
  $("#acc-close").onclick = closeModal;
  $$(".accrow").forEach(r => {
    r.onclick = async e => {
      if (e.target.closest(".x")) {
        ACC = await api("accounts.remove", { uuid: r.dataset.u }).catch(err => (fail(err), ACC));
      } else {
        ACC = await api("accounts.select", { uuid: r.dataset.u }).catch(err => (fail(err), ACC));
      }
      renderAccountCard(); openAccounts();
    };
  });
  $("#acc-ms").onclick = async () => {
    toast(T("Окно входа Microsoft открыто…"));
    try {
      ACC = await api("accounts.loginMicrosoft");
      renderAccountCard();
      const a = ACC.accounts.find(x => x.uuid === ACC.active);
      toast(T("Вход выполнен:") + " " + (a ? a.name : ""));
      closeModal();
    } catch (e) { fail(e); }
  };
  const addOff = async () => {
    try { ACC = await api("accounts.addOffline", { name: $("#acc-off").value }); renderAccountCard(); openAccounts(); } catch (e) { fail(e); }
  };
  $("#acc-off-add").onclick = addOff;
  $("#acc-off").onkeydown = e => { if (e.key === "Enter") addOff(); };
}

$("#check-updates").onclick = () => checkUpdates(false);
async function checkUpdates(quiet) {
  try {
    const r = await api("update.check");
    if (!r.configured) { if (!quiet) toast(T("Не указан репозиторий обновлений (Настройки → Обновления)"), true); return; }
    if (r.clients > 0) toast(T("Новых версий:") + " " + r.clients);
    if (r.launcher) {
      if (S.AutoUpdate) {
        toast(T("Обновляю лаунчер до") + " " + r.launcher + "…");
        await api("update.applyLauncher");
        return;
      }
      toast(T("Доступен лаунчер") + " " + r.launcher);
    }
    if (!r.clients && !r.launcher && !quiet) toast(T("Нет новых версий"));
    await refreshPlay();
  } catch (e) { if (!quiet) fail(e); }
}

setInterval(async () => {
  if (currentTab !== "play" || document.hidden) return;
  try {
    const i = await api("play.info");
    if (i.running !== INFO.running || (i.releases || []).length !== (INFO.releases || []).length) { INFO = i; refreshPlay(); }
  } catch { }
}, 5000);

/* ================================================================ builds */
let selBuild = null, selSub = "mod";
let cat = { source: "modrinth", kind: "mod", query: "", offset: 0, hits: [], total: 0 };
const LOADER_ICON = { fabric: "F", quilt: "Q", forge: "⚒", neoforge: "N", vanilla: "V" };

async function renderBuilds(reload = true) {
  if (reload) await loadBuilds();
  if (selBuild && !BUILDS.some(b => b.id === selBuild)) selBuild = null;
  if (!selBuild && BUILDS.length) selBuild = (BUILDS.find(b => b.isMain) || BUILDS[0]).id;
  renderBuildList();
  renderBuildDetail();
}

function renderBuildList() {
  $("#build-list").innerHTML = BUILDS.map((b, i) => `
    <div class="bcard ${b.id === selBuild ? "sel" : ""}" data-id="${esc(b.id)}" style="animation-delay:${i * 30}ms">
      <div class="bicon">${esc((b.name || "?")[0].toUpperCase())}</div>
      <div style="min-width:0">
        <div class="bname">${esc(b.name)} ${b.isMain ? `<span class="chip accent">${esc(T("Основная"))}</span>` : ""}</div>
        <div class="bmeta">${esc(b.minecraft)} · ${esc(b.loader)} · ${b.mods} ${LANG === "en" ? "mods" : "модов"}</div>
      </div>
    </div>`).join("") || `<div class="hint">${esc(T("Нет сборок"))}</div>`;
  $$("#build-list .bcard").forEach(c => c.onclick = () => { selBuild = c.dataset.id; cat.offset = 0; cat.hits = []; renderBuilds(false); });
}

function renderBuildDetail() {
  const b = BUILDS.find(x => x.id === selBuild);
  const d = $("#build-detail");
  if (!b) { d.innerHTML = `<div class="empty">${esc(T("Выберите сборку слева или создайте новую"))}</div>`; return; }
  const subs = [["mod", "Моды", b.mods], ["resourcepack", "Ресурспаки", b.resourcepacks], ["shader", "Шейдеры", b.shaders], ["catalog", "Каталог", null]];
  d.innerHTML = `
    <div class="dhead">
      <div class="bicon">${esc((b.name || "?")[0].toUpperCase())}</div>
      <div>
        <div class="dtitle">${esc(b.name)}</div>
        <div class="bmeta">Minecraft ${esc(b.minecraft)} · ${esc(b.loader)} ${esc(b.loaderVersion || "")}${b.starfall ? " · Starfall " + esc(b.starfall) : ""}</div>
        <div class="bmeta">${esc(T("Последний запуск"))}: ${b.lastLaunch ? esc(new Date(b.lastLaunch).toLocaleString()) : esc(T("никогда"))}</div>
      </div>
      <div class="actions">
        <button class="btn accent small" id="b-play">▶ ${esc(T("Играть"))}</button>
        ${b.isMain ? "" : `<button class="btn small" id="b-main">${esc(T("Сделать основной"))}</button>`}
        <button class="btn small" id="b-open">${esc(T("Папка"))}</button>
        <button class="btn small danger" id="b-del">${esc(T("Удалить"))}</button>
      </div>
    </div>
    <div class="subtabs">${subs.map(([k, n, c]) => `<button class="subtab ${selSub === k ? "active" : ""}" data-k="${k}">${esc(T(n))}${c != null ? ` <span class="chip">${c}</span>` : ""}</button>`).join("")}</div>
    <div class="dbody" id="dbody"></div>`;
  $$(".subtab", d).forEach(s => s.onclick = () => { selSub = s.dataset.k; renderBuildDetail(); });
  $("#b-play").onclick = async () => { $("#pick-build").value = b.id; await $("#pick-build").onchange(); $("#play").onclick(); };
  if ($("#b-main")) $("#b-main").onclick = async () => { await api("builds.setMain", { id: b.id }).catch(fail); S.MainBuild = b.id; renderBuilds(); };
  $("#b-open").onclick = () => api("builds.open", { id: b.id }).catch(fail);
  $("#b-del").onclick = () => confirmModal(T("Удалить сборку?"), `<b>${esc(b.name)}</b><br>${esc(T("Сборка будет перемещена в корзину."))}`, async () => {
    try { await api("builds.delete", { id: b.id }); toast(T("Удалено")); selBuild = null; renderBuilds(); } catch (e) { fail(e); }
  });
  selSub === "catalog" ? renderCatalog(b) : renderContent(b, selSub);
}

async function renderContent(b, kind) {
  const body = $("#dbody");
  let items = [];
  try { items = await api("builds.content", { id: b.id, kind }) || []; } catch (e) { fail(e); }
  if (selSub !== kind || selBuild !== b.id) return;
  body.innerHTML = items.length ? items.map(it => `
    <div class="citem ${it.enabled ? "" : "off"}" data-file="${esc(it.file)}">
      <button class="switch ${it.enabled ? "on" : ""}"></button>
      <span class="cname" title="${esc(it.name)}">${esc(it.name)}</span>
      <span class="bmeta">${(it.size / 1048576).toFixed(1)} MB</span>
      <button class="btn small danger x">✕</button>
    </div>`).join("") : `<div class="empty">${esc(T("Пусто"))}</div>`;
  $$(".citem", body).forEach(row => {
    const file = row.dataset.file;
    $(".switch", row).onclick = async () => { try { await api("builds.toggle", { id: b.id, kind, file }); renderContent(b, kind); } catch (e) { fail(e); } };
    $(".x", row).onclick = async () => { try { await api("builds.remove", { id: b.id, kind, file }); await loadBuilds(); renderBuilds(false); } catch (e) { fail(e); } };
  });
}

function renderCatalog(b) {
  const body = $("#dbody");
  const kinds = [["mod", "Моды"], ["resourcepack", "Ресурспаки"], ["shader", "Шейдеры"], ["modpack", "Сборки (модпаки)"]];
  body.innerHTML = `
    <div class="catbar">
      <div class="seg" id="seg-src">
        <button data-v="modrinth" class="${cat.source === "modrinth" ? "active" : ""}">Modrinth</button>
        <button data-v="curseforge" class="${cat.source === "curseforge" ? "active" : ""}">CurseForge</button>
      </div>
      <div class="seg" id="seg-kind">${kinds.map(([k, n]) => `<button data-v="${k}" class="${cat.kind === k ? "active" : ""}">${esc(T(n))}</button>`).join("")}</div>
      <input id="cat-q" placeholder="${esc(T("Поиск..."))}" value="${esc(cat.query)}">
      <button class="btn accent" id="cat-go">${esc(T("Найти"))}</button>
    </div>
    <div class="bmeta" style="margin-bottom:8px">Minecraft ${esc(b.minecraft)} · ${esc(b.loader)}</div>
    <div class="grid" id="cat-grid"></div>
    <div class="more" id="cat-more"></div>`;
  $$("#seg-src button").forEach(x => x.onclick = () => { cat.source = x.dataset.v; search(b, true); renderCatalogBar(); });
  $$("#seg-kind button").forEach(x => x.onclick = () => { cat.kind = x.dataset.v; search(b, true); renderCatalogBar(); });
  $("#cat-go").onclick = () => { cat.query = $("#cat-q").value; search(b, true); };
  $("#cat-q").onkeydown = e => { if (e.key === "Enter") { cat.query = e.target.value; search(b, true); } };
  if (cat.hits.length && cat.build === b.id) drawHits(b); else search(b, true);
}
function renderCatalogBar() {
  $$("#seg-src button").forEach(x => x.classList.toggle("active", x.dataset.v === cat.source));
  $$("#seg-kind button").forEach(x => x.classList.toggle("active", x.dataset.v === cat.kind));
}

let searchSeq = 0;
async function search(b, reset) {
  if (reset) { cat.offset = 0; cat.hits = []; }
  cat.build = b.id;
  const my = ++searchSeq;
  if (reset) $("#cat-grid").innerHTML = `<div class="hint">…</div>`;
  try {
    const r = await api("catalog.search", { source: cat.source, query: cat.query, kind: cat.kind, mc: b.minecraft, loader: b.loader, offset: cat.offset });
    if (my !== searchSeq) return;
    cat.hits = cat.hits.concat(r.hits || []);
    cat.total = r.total || 0;
    drawHits(b);
  } catch (e) {
    if (my !== searchSeq) return;
    const key = e.message === "NO_CF_KEY";
    $("#cat-grid").innerHTML = `<div class="hint">${esc(key ? T("Введите ключ CurseForge в настройках") : e.message)}</div>`;
    $("#cat-more").innerHTML = "";
  }
}
function fmtNum(n) { return n >= 1e6 ? (n / 1e6).toFixed(1) + "M" : n >= 1e3 ? (n / 1e3).toFixed(1) + "K" : String(n); }
function drawHits(b) {
  $("#cat-grid").innerHTML = cat.hits.map((h, i) => `
    <div class="proj" style="animation-delay:${(i % 24) * 15}ms">
      ${h.icon ? `<img src="${esc(h.icon)}" loading="lazy" alt="">` : `<div class="noimg"></div>`}
      <div style="min-width:0;flex:1">
        <div class="ptitle">${esc(h.title)}</div>
        <div class="pdesc">${esc(h.description)}</div>
        <div class="pfoot"><span>${esc(h.author || "")} · ${fmtNum(h.downloads || 0)} ${esc(T("загрузок"))}</span>
          <button class="btn small accent" data-i="${i}">${esc(T("Установить"))}</button></div>
      </div>
    </div>`).join("") || `<div class="hint">${esc(T("Пусто"))}</div>`;
  $$("#cat-grid [data-i]").forEach(btn => btn.onclick = () => install(b, cat.hits[+btn.dataset.i], btn));
  $("#cat-more").innerHTML = cat.hits.length < cat.total ? `<button class="btn" id="cat-more-btn">${esc(T("Ещё"))}</button>` : "";
  if ($("#cat-more-btn")) $("#cat-more-btn").onclick = () => { cat.offset = cat.hits.length; search(b, false); };
}
async function install(b, h, btn) {
  btn.disabled = true; btn.textContent = "…";
  try {
    const r = await api("catalog.install", { source: h.source, kind: cat.kind, build: b.id, project: h.id, title: h.title });
    btn.textContent = "✓";
    if (cat.kind === "modpack") { toast(T("Сборка создана") + ": " + h.title); selBuild = r; }
    else toast(T("Установлено") + ": " + h.title);
    await loadBuilds();
    if (cat.kind === "modpack") renderBuilds(false);
    else { renderBuildList(); refreshDetailCounters(); } // keep the catalog results on screen
  } catch (e) { fail(e); btn.disabled = false; btn.textContent = T("Установить"); }
}
function refreshDetailCounters() {
  const b = BUILDS.find(x => x.id === selBuild);
  if (!b) return;
  const counts = { mod: b.mods, resourcepack: b.resourcepacks, shader: b.shaders };
  $$(".subtab").forEach(s => { const c = $(".chip", s); if (c && counts[s.dataset.k] != null) c.textContent = counts[s.dataset.k]; });
}

const SF_VERSIONS = [
  ["1.21.11", "полный клиент"], ["1.16.5", "ядро: HUD, зум, меню"], ["1.8.9", "ядро: HUD, зум, меню · PvP"],
];
$("#new-build").onclick = async () => {
  let kind = "starfall", versions = [];
  const draw = () => {
    const sf = kind === "starfall";
    modal(`<h2>${esc(T("Создать сборку"))}</h2>
      <div class="kinds">
        <button class="kind ${sf ? "sel" : ""}" data-kind="starfall"><b>✦ Starfall Client</b><span>${esc(T("Клиент с меню, HUD и косметикой"))}</span></button>
        <button class="kind ${sf ? "" : "sel"}" data-kind="vanilla"><b>${esc(T("Ванилла"))}</b><span>${esc(T("Чистый Minecraft или свои моды"))}</span></button>
      </div>
      <label class="field">${esc(T("Название"))}<input id="nb-name" value="${esc(sf ? "Starfall" : (LANG === "en" ? "My build" : "Моя сборка"))}"></label>
      ${sf ? `<label class="field">${esc(T("Версия"))}<select id="nb-mc">${SF_VERSIONS.map(([v, d]) => `<option value="${v}">${v} — ${esc(T(d))}</option>`).join("")}</select></label>
             <div class="hint">${esc(T("Загрузчик и Starfall ставятся сами: Fabric для 1.21.11 и 1.16.5, Legacy Fabric для 1.8.9."))}</div>`
         : `<label class="field">${esc(T("Версия Minecraft"))}<select id="nb-mc">${(versions.length ? versions : ["1.21.11"]).map(v => `<option ${v === "1.21.11" ? "selected" : ""}>${esc(v)}</option>`).join("")}</select></label>
            <label class="field">${esc(T("Загрузчик"))}<select id="nb-loader">
              <option value="vanilla">Vanilla</option><option value="fabric">Fabric</option><option value="quilt">Quilt</option><option value="legacyfabric">Legacy Fabric (1.13−)</option></select></label>`}
      <div class="foot"><button class="btn" id="nb-cancel">${esc(T("Отмена"))}</button><button class="btn accent" id="nb-ok">${esc(T("Создать"))}</button></div>`);
    $$(".kind").forEach(b => b.onclick = () => { kind = b.dataset.kind; draw(); });
    $("#nb-cancel").onclick = closeModal;
    if (sf) $("#nb-mc").onchange = () => { $("#nb-name").value = "Starfall " + $("#nb-mc").value; };
    if (sf) $("#nb-name").value = "Starfall " + $("#nb-mc").value;
    $("#nb-ok").onclick = async () => {
      const args = { type: kind, name: $("#nb-name").value.trim() || "Build", minecraft: $("#nb-mc").value, loader: sf ? "" : $("#nb-loader").value };
      closeModal();
      onProgress(T("Создать сборку") + "…", 0.1);
      try {
        selBuild = await api("builds.create", args);
        onProgress(T("Готово"), 1);
        toast(T("Сборка создана") + ": " + args.name);
        renderBuilds();
      } catch (e) { onProgress(T("Ошибка"), 1); fail(e); renderBuilds(); }
    };
  };
  draw();
  try { versions = await api("mc.versions"); } catch { }
};
$("#import-pack").onclick = async () => {
  try {
    const id = await api("catalog.importPack");
    if (id) { selBuild = id; toast(T("Сборка создана")); renderBuilds(); }
  } catch (e) { fail(e); }
};

/* ================================================================ modal */
function modal(html) { $("#modal-box").innerHTML = html; $("#modal").classList.remove("hidden"); }
function closeModal() { $("#modal").classList.add("hidden"); }
$("#modal").addEventListener("mousedown", e => { if (e.target.id === "modal") closeModal(); });
document.addEventListener("keydown", e => { if (e.key === "Escape") closeModal(); });
function confirmModal(title, html, ok) {
  modal(`<h2>${esc(title)}</h2><div style="color:var(--sub)">${html}</div>
    <div class="foot"><button class="btn" id="cm-no">${esc(T("Отмена"))}</button><button class="btn accent" id="cm-yes">${esc(T("Удалить"))}</button></div>`);
  $("#cm-no").onclick = closeModal;
  $("#cm-yes").onclick = () => { closeModal(); ok(); };
}

/* ================================================================ friends */
let FR = { friends: [], outgoing: [], chats: {}, configFound: true }, selFriend = null;
const HUES = n => { let h = 0; for (const c of n) h = (h * 31 + c.charCodeAt(0)) % 360; return h; };
const avatar = n => `<div class="avatar" style="background:hsl(${HUES(n)} 60% 45%)">${esc(n[0].toUpperCase())}</div>`;

async function loadFriends() {
  try { FR = await api("friends.get"); } catch (e) { fail(e); }
  renderFriends();
}
function renderFriends() {
  const list = $("#friend-list");
  const unread = 0;
  let html = `<div class="section-title">${esc(T("Друзья"))} · ${FR.friends.length}</div>`;
  html += FR.friends.length ? FR.friends.map(n => `
    <div class="fcard ${n === selFriend ? "sel" : ""}" data-n="${esc(n)}">${avatar(n)}
      <div><div class="bname">${esc(n)}</div><div class="bmeta">${(FR.chats[n] || []).length ? esc(((FR.chats[n].slice(-1)[0] || {}).t || "").slice(0, 32)) : ""}</div></div>
      <button class="btn small danger x" title="${esc(T("Удалить из друзей"))}">✕</button></div>`).join("")
    : `<div class="hint">${esc(T("Пока нет друзей"))}</div>`;
  if (FR.outgoing.length) {
    html += `<div class="section-title">${esc(T("Отправленные заявки"))}</div>` + FR.outgoing.map(n => `
      <div class="fcard" data-n="${esc(n)}" data-out="1">${avatar(n)}
        <div><div class="bname">${esc(n)}</div><div class="bmeta">${esc(T("ожидает"))}</div></div>
        <button class="btn small danger x">✕</button></div>`).join("");
  }
  list.innerHTML = html;
  $$(".fcard", list).forEach(c => {
    c.onclick = e => { if (e.target.closest(".x")) return; if (!c.dataset.out) { selFriend = c.dataset.n; renderFriends(); } };
    $(".x", c).onclick = async () => { try { await api("friends.remove", { name: c.dataset.n }); if (selFriend === c.dataset.n) selFriend = null; loadFriends(); } catch (e) { fail(e); } };
  });
  $("#friend-hint").textContent = FR.configFound ? "" : T("Конфиг Starfall не найден — запустите основную сборку хотя бы раз.");
  renderChat();
}
function renderChat() {
  const box = $("#friend-chat");
  if (!selFriend) { box.innerHTML = `<div class="empty">${esc(T("Выберите друга, чтобы посмотреть переписку"))}</div>`; return; }
  const msgs = FR.chats[selFriend] || [];
  box.innerHTML = `
    <div class="dhead">${avatar(selFriend)}<div class="dtitle">${esc(selFriend)}</div></div>
    <div class="chat" id="chat">${msgs.length ? msgs.map(m => `<div class="bubble ${m.m ? "mine" : ""}">${esc(m.t)}<time>${m.at ? esc(new Date(m.at).toLocaleString()) : ""}</time></div>`).join("") : `<div class="empty">${esc(T("Переписка пуста"))}</div>`}</div>
    <div class="note">${esc(T("Сообщения и заявки доставляются в игре, когда вы с другом на одном сервере. Лаунчер показывает историю и ставит заявки в очередь."))}</div>`;
  const c = $("#chat"); c.scrollTop = c.scrollHeight;
}
async function addFriend() {
  const name = $("#friend-name").value.trim();
  if (!name) return;
  try {
    const n = await api("friends.request", { name });
    toast(T("Заявка поставлена в очередь:") + " " + n);
    $("#friend-name").value = "";
    loadFriends();
  } catch (e) { fail(e); }
}
$("#friend-add").onclick = addFriend;
$("#friend-name").onkeydown = e => { if (e.key === "Enter") addFriend(); };

/* ================================================================ settings */
const SUPPORT_EMAIL = "starfallsupport@gmail.com";
const ACCENTS = ["#5B8CFF", "#9B7BFF", "#FF5BD6", "#FF6B6B", "#FFB347", "#4CD97B", "#2ED3C6", "#FFFFFF"];
function renderSettings() {
  const sel = (key, opts) => `<select data-k="${key}">${opts.map(([v, n]) => `<option value="${esc(v)}" ${String(S[key]) === v ? "selected" : ""}>${esc(T(n))}</option>`).join("")}</select>`;
  const sw = key => `<button class="switch ${S[key] ? "on" : ""}" data-sw="${key}"></button>`;
  const row = (lbl, ctl, desc = "") => `<div class="srow"><div><div class="lbl">${esc(T(lbl))}</div>${desc ? `<div class="desc">${desc}</div>` : ""}</div>${ctl}</div>`;
  const range = (key, min, max, step, fmt) => `<div class="row gap"><input type="range" data-r="${key}" min="${min}" max="${max}" step="${step}" value="${S[key]}"><b class="rv" style="width:52px;text-align:right">${fmt(S[key])}</b></div>`;
  const seg = (key, opts) => `<div class="seg">${opts.map(([v, n]) => `<button data-seg="${key}" data-v="${v}" class="${String(S[key]) === v ? "active" : ""}">${esc(T(n))}</button>`).join("")}</div>`;
  const custom = !ACCENTS.includes((S.Accent || "").toUpperCase());
  $("#settings").innerHTML = `
    <div class="sgroup"><h3>${esc(T("Общие"))}</h3>
      ${row("Язык", sel("Language", [["auto", "Авто"], ["ru", "Русский"], ["en", "English"]]))}
      ${row("Сворачивать при запуске игры", sw("CloseOnLaunch"))}
      ${row("Показывать «Что нового»", sw("ShowNews"))}
    </div>
    <div class="sgroup" style="animation-delay:40ms"><h3>${esc(T("Внешний вид"))}</h3>
      ${row("Стиль", seg("Style", [["smooth", "Гладкий"], ["pixel", "Пиксельный"]]), esc(T("Как в клиенте: плавные формы или пиксели")))}
      ${row("Тема", sel("Theme", [["dark", "Тёмная"], ["glass", "Стекло"], ["midnight", "Полночь"], ["oled", "OLED"]]))}
      ${row("Акцент", `<div class="swatches">${ACCENTS.map(c => `<button data-acc="${c}" class="${(S.Accent || "").toUpperCase() === c ? "sel" : ""}" style="background:${c}"></button>`).join("")}<label class="picker ${custom ? "sel" : ""}" title="${esc(T("Свой цвет"))}"><input type="color" id="acc-custom" value="${esc(S.Accent || "#5B8CFF")}"></label></div>`)}
      ${row("Прозрачность панелей", range("PanelOpacity", 30, 100, 5, v => v + "%"))}
      ${S.Style === "pixel" ? "" : row("Скругление углов", range("Radius", 0, 22, 1, v => v + "px"))}
    </div>
    <div class="sgroup" style="animation-delay:60ms"><h3>${esc(T("Анимированный фон"))}</h3>
      <div class="walls">${WALLS.map(([v, n]) => `<button class="wall ${S.Wallpaper === v ? "sel" : ""}" data-wall="${v}"><canvas width="96" height="54" data-prev="${v}"></canvas><span>${esc(T(n))}</span></button>`).join("")}</div>
      ${row("Скорость анимации", range("AnimSpeed", 0.25, 2.5, 0.25, v => "×" + (+v).toFixed(2).replace(/\.?0+$/, "")))}
      ${row("Частицы и звёзды", seg("Particles", [["0", "Мало"], ["1", "Средне"], ["2", "Много"], ["3", "Максимум"]]))}
      ${row("Меньше анимаций", sw("ReduceMotion"), esc(T("Спокойный фон и без переходов")))}
    </div>
    <div class="sgroup" style="animation-delay:80ms"><h3>${esc(T("Игра"))}</h3>
      ${row("Память (ОЗУ)", `<div class="row gap"><input type="range" min="2048" max="16384" step="512" value="${S.MaxRamMb}" id="ram"><b id="ram-v" style="width:62px;text-align:right">${(S.MaxRamMb / 1024).toFixed(1)} GB</b></div>`)}
      ${row("Основная сборка", `<select data-k="MainBuild">${BUILDS.map(b => `<option value="${esc(b.id)}" ${b.id === S.MainBuild ? "selected" : ""}>${esc(b.name)}</option>`).join("")}</select>`)}
      ${row("Java", `<div class="row gap">${S.JavaPath ? `<button class="btn small" id="java-reset">${esc(T("Сбросить"))}</button>` : ""}<button class="btn small" id="pick-java">${esc(T("Выбрать"))}</button></div>`, esc(S.JavaPath || T("Авто (Java от Mojang)")))}
      ${row("Папка сборок", `<button class="btn small" id="pick-inst">${esc(T("Выбрать"))}</button>`, esc(S.instancesResolved || ""))}
      ${row("Файлы игры", "", esc(T("Версии, библиотеки, ресурсы и Java — общие для всех сборок")) + "<br>" + esc(S.gameDir || ""))}
    </div>
    <div class="sgroup" style="animation-delay:120ms"><h3>${esc(T("Обновления"))}</h3>
      ${row("Автообновление", sw("AutoUpdate"), esc(T("Клиент и лаунчер обновляются сами, когда выходит новая версия")))}
      ${row("Репозиторий GitHub", `<input data-in="UpdateRepo" value="${esc(S.UpdateRepo || "")}" placeholder="${esc(S.defaultRepo || "owner/repo")}">`, esc(T("Откуда брать релизы: владелец/репозиторий")))}
      ${row("Папка обновлений", `<button class="btn small" id="pick-upd">${esc(T("Выбрать"))}</button>`, esc(S.UpdateFolder))}
      ${row("Проверить сейчас", `<button class="btn small" id="upd-now">${esc(T("Проверить"))}</button>`)}
    </div>
    <div class="sgroup" style="animation-delay:160ms"><h3>CurseForge</h3>
      ${row("Ключ CurseForge API", `<input type="password" data-in="CurseForgeKey" value="${esc(S.CurseForgeKey)}" placeholder="$2a$10$…">`, esc(T("Нужен для поиска на CurseForge. Modrinth работает без ключа.")) + ` <button class="link" id="cf-link">${esc(T("Получить ключ"))}</button>`)}
    </div>
    <div class="sgroup support" style="animation-delay:180ms"><h3>${esc(T("Поддержка"))}</h3>
      <div class="support-head">
        <img src="support.png" alt="">
        <div><div class="lbl">${esc(T("Что-то не работает? Напишите нам"))}</div>
          <button class="link mail" id="sup-copy-text" title="${esc(T("Скопировать"))}">${esc(SUPPORT_EMAIL)}</button></div>
      </div>
      <div class="row gap support-actions">
        <button class="btn accent small" id="sup-mail">✉ ${esc(T("Написать"))}</button>
        <button class="btn small" id="sup-copy">${esc(T("Скопировать адрес"))}</button>
        <button class="btn small" id="sup-logs">${esc(T("Открыть логи"))}</button>
      </div>
      <div class="desc">${esc(T("Опишите проблему и приложите файл starfall-launcher.log из папки логов сборки — так мы быстрее разберёмся."))}</div>
    </div>
    <div class="sgroup" style="animation-delay:200ms"><h3>${esc(T("О лаунчере"))}</h3>
      ${row("Версия", `<span class="chip accent">${esc(S.launcherVersion || "1.0.0")}</span>`)}
      ${row("Папка данных", `<button class="btn small" id="data-dir">${esc(T("Открыть"))}</button>`, "%APPDATA%\\StarfallLauncher")}
    </div>`;
  const root = $("#settings");
  $$("select[data-k]", root).forEach(s => s.onchange = async () => {
    await saveSettings({ [s.dataset.k]: s.value });
    if (s.dataset.k === "MainBuild") BUILDS.forEach(b => b.isMain = b.id === s.value);
    applyLook(); renderSettings(); renderNews();
  });
  $$("[data-sw]", root).forEach(b => b.onclick = () => { saveSettings({ [b.dataset.sw]: !S[b.dataset.sw] }); b.classList.toggle("on"); applyLook(); });
  $$("[data-seg]", root).forEach(b => b.onclick = () => {
    const key = b.dataset.seg, v = key === "Particles" ? +b.dataset.v : b.dataset.v;
    saveSettings({ [key]: v }); applyLook(); renderSettings();
  });
  $$("[data-r]", root).forEach(r => {
    const key = r.dataset.r, out = r.parentElement.querySelector(".rv");
    r.oninput = () => {
      S[key] = +r.value;
      out.textContent = key === "AnimSpeed" ? "×" + (+r.value).toFixed(2).replace(/\.?0+$/, "") : r.value + (key === "Radius" ? "px" : "%");
      applyLook();
    };
    r.onchange = () => saveSettings({ [key]: +r.value });
  });
  $$("[data-wall]", root).forEach(b => b.onclick = () => { saveSettings({ Wallpaper: b.dataset.wall }); $$("[data-wall]", root).forEach(x => x.classList.toggle("sel", x === b)); });
  $$("[data-acc]", root).forEach(b => b.onclick = () => { saveSettings({ Accent: b.dataset.acc }); applyLook(); renderSettings(); });
  $("#acc-custom").oninput = e => { S.Accent = e.target.value.toUpperCase(); applyLook(); };
  $("#acc-custom").onchange = e => { saveSettings({ Accent: e.target.value.toUpperCase() }); renderSettings(); };
  $$("[data-in]", root).forEach(i => i.onchange = () => saveSettings({ [i.dataset.in]: i.value.trim() }, false));
  const ram = $("#ram");
  ram.oninput = () => $("#ram-v").textContent = (ram.value / 1024).toFixed(1) + " GB";
  ram.onchange = () => saveSettings({ MaxRamMb: +ram.value });
  $("#pick-java").onclick = async () => {
    const p = await api("settings.pickFile", { filter: "Java|javaw.exe;java.exe" }).catch(fail);
    if (p) { await saveSettings({ JavaPath: p }); renderSettings(); }
  };
  if ($("#java-reset")) $("#java-reset").onclick = async () => { await saveSettings({ JavaPath: "" }); renderSettings(); };
  $("#pick-inst").onclick = async () => {
    const p = await api("settings.pickFolder", { start: S.instancesResolved }).catch(fail);
    if (p) { await saveSettings({ InstancesDir: p }); await reloadSettings(); await loadBuilds(); renderSettings(); }
  };
  $("#pick-upd").onclick = async () => {
    const p = await api("settings.pickFolder", { start: S.UpdateFolder }).catch(fail);
    if (p) { await saveSettings({ UpdateFolder: p }); renderSettings(); }
  };
  $("#upd-now").onclick = () => checkUpdates(false);
  $("#cf-link").onclick = () => api("open.url", { url: "https://console.curseforge.com/" });
  $("#data-dir").onclick = () => api("settings.openDataFolder");
  const copyMail = async () => { try { await api("support.copy"); toast(T("Адрес скопирован") + ": " + SUPPORT_EMAIL); } catch (e) { fail(e); } };
  $("#sup-copy").onclick = copyMail;
  $("#sup-copy-text").onclick = copyMail;
  $("#sup-mail").onclick = async () => {
    try { await api("support.mail"); }
    catch (e) { copyMail(); toast(T("Почтовое приложение не найдено — адрес скопирован, напишите с любой почты"), true); }
  };
  $("#sup-logs").onclick = () => api("support.logs", { id: S.MainBuild }).catch(fail);
  BG.previews(root);
}
async function reloadSettings() { try { S = await api("settings.get"); } catch (e) { fail(e); } }

/* ================================================================ boot */
(async function boot() {
  await reloadSettings();
  applyLook();
  renderNews();
  $("#sidefoot").textContent = "Starfall Launcher " + (S.launcherVersion || "");
  await loadAccounts();
  await loadBuilds();
  await refreshPlay();
  if (S.AutoUpdate) checkUpdates(true);
  // friends badge: number of queued requests
  try { FR = await api("friends.get"); const n = FR.friends.length; if (n) { $("#friends-badge").textContent = n; $("#friends-badge").classList.remove("hidden"); } } catch { }
})();

/* ================================================================ mock (browser preview only) */
function MOCK(method, a) {
  const M = window.__mock || (window.__mock = {
    settings: { Language: "auto", Theme: "dark", Accent: "#5B8CFF", MaxRamMb: 4096, CloseOnLaunch: false, AutoUpdate: true, UpdateFolder: "C:\\Users\\you\\Desktop\\Starfall Client", UpdateRepo: "", CurseForgeKey: "", JavaPath: "", InstancesDir: "", MainBuild: "starfall client", StarfallVersion: "latest", Wallpaper: "space", Style: "smooth", AnimSpeed: 1, Particles: 2, PanelOpacity: 85, Radius: 12, ReduceMotion: false, ShowNews: true, instancesResolved: "C:\\Users\\you\\AppData\\Roaming\\PrismLauncher\\instances", gameDir: "C:\\Users\\you\\AppData\\Roaming\\StarfallLauncher\\game", launcherVersion: "1.2.0", defaultRepo: "" },
    acc: { accounts: [], active: null },
    builds: [
      { id: "starfall client", name: "starfall client", minecraft: "1.21.11", loader: "fabric", loaderVersion: "0.18.1", mods: 9, resourcepacks: 1, shaders: 2, starfall: "1.0.7", lastLaunch: Date.now() - 3600e3, isMain: true },
      { id: "survival", name: "Survival+", minecraft: "1.21.4", loader: "fabric", loaderVersion: "0.16.10", mods: 42, resourcepacks: 3, shaders: 1, starfall: null, lastLaunch: null, isMain: false },
    ],
    friends: { friends: ["Steve_Pro", "Alex2010", "NightFox"], outgoing: ["Builder_7"], chats: { Steve_Pro: [{ m: false, t: "го на сервер?", at: Date.now() - 6e5 }, { m: true, t: "иду, 5 минут", at: Date.now() - 5e5 }] }, configFound: true },
  });
  const ok = v => new Promise(r => setTimeout(() => r(JSON.parse(JSON.stringify(v))), 120));
  const a0 = () => Math.random().toString(16).slice(2);
  const argName = () => { if (!/^[A-Za-z0-9_]{3,16}$/.test(a.name || "")) throw new Error("Ник: 3–16 символов"); return a.name; };
  switch (method) {
    case "settings.get": return ok({ ...M.settings });
    case "settings.set": Object.assign(M.settings, a); return ok(null);
    case "builds.list": return ok(M.builds.map(b => ({ ...b, isMain: b.id === M.settings.MainBuild })));
    case "builds.setMain": M.settings.MainBuild = a.id; return ok(null);
    case "builds.content": return ok(Array.from({ length: a.kind === "mod" ? 9 : 2 }, (_, i) => ({ file: `${a.kind}-${i}.jar`, name: ["sodium", "lithium", "fabric-api", "starfall-client-1.0.7", "iris", "modmenu", "krypton", "ferritecore", "entityculling"][i] + ".jar", enabled: i !== 5, size: 1048576 * (i + 1) })));
    case "play.info": return ok({ releases: [{ version: "1.0.8", minecraft: "1.21.11" }, { version: "1.0.7", minecraft: "1.21.11" }, { version: "1.0.8", minecraft: "1.16.5" }, { version: "1.0.8", minecraft: "1.8.9" }], supported: ["1.21.11", "1.16.5", "1.8.9"], main: M.settings.MainBuild, running: false });
    case "play.checkUpdates": case "update.check": return ok({ clients: 0, launcher: null, configured: true });
    case "play.launch": return ok("1.0.7");
    case "mc.versions": return ok(["1.21.11", "1.21.10", "1.21.4", "1.20.1"]);
    case "catalog.search": return ok({ total: 30, hits: Array.from({ length: 12 }, (_, i) => ({ id: "p" + i, title: (a.kind === "shader" ? "Shader " : "Project ") + (a.offset + i + 1), description: "Описание проекта из каталога " + a.source + ", пример текста для превью.", icon: null, author: "author" + i, downloads: 123456 * (i + 1), source: a.source })) });
    case "catalog.install": return ok({});
    case "support.copy": case "support.logs": return ok(null);
    case "support.mail": return Promise.reject(new Error("NO_MAIL_APP"));
    case "accounts.list": return ok(M.acc);
    case "accounts.addOffline": { const a = { uuid: "u" + a0(), name: argName(), type: "offline" }; M.acc.accounts.push(a); M.acc.active = a.uuid; return ok(M.acc); }
    case "accounts.loginMicrosoft": { const a = { uuid: "m" + a0(), name: "Player_MS", type: "msa" }; M.acc.accounts.push(a); M.acc.active = a.uuid; return ok(M.acc); }
    case "accounts.select": M.acc.active = a.uuid; return ok(M.acc);
    case "accounts.remove": M.acc.accounts = M.acc.accounts.filter(x => x.uuid !== a.uuid); if (M.acc.active === a.uuid) M.acc.active = (M.acc.accounts[0] || {}).uuid || null; return ok(M.acc);
    case "friends.get": return ok(JSON.parse(JSON.stringify(M.friends)));
    case "friends.request": M.friends.outgoing.push(a.name); return ok(a.name);
    case "friends.remove": M.friends.friends = M.friends.friends.filter(n => n !== a.name); M.friends.outgoing = M.friends.outgoing.filter(n => n !== a.name); return ok(null);
    default: return ok(null);
  }
}
